# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['localstack_wrapper']
install_requires = \
['localstack==0.14.0.9']

entry_points = \
{'console_scripts': ['localstack-wrapper = localstack_wrapper:main']}

setup_kwargs = {
    'name': 'localstack-wrapper',
    'version': '0.1.0',
    'description': 'A simple wrapper around localstack to allow it to be integrated with nix using poetry2nix',
    'long_description': None,
    'author': 'foo',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
